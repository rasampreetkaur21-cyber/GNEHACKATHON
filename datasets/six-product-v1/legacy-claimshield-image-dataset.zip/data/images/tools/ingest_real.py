#!/usr/bin/env python3
"""
Add a REAL image (your own photo, or one from Roboflow Universe etc.) to the dataset.

It strips EXIF/GPS, fixes rotation, resizes to <=1568 px, saves as JPEG under data/images/real/,
and fills in the manifest slot with source + license + the ground truth you type in.

Examples
--------
# Your own photo of the serial sticker on a Galaxy A26:
python data/images/tools/ingest_real.py --slot real-samsung-galaxy-a26-5g-back-label \
    --file ~/Pictures/a26_back.jpg --origin REAL_OWN_PHOTO \
    --expected '{"serial_text":"R58T1234567","observed_brand":"Samsung","identifying_evidence_kind":"LABEL","image_relevance":"RELEVANT"}'

# A Roboflow Universe image (source URL + license are REQUIRED):
python data/images/tools/ingest_real.py --slot real-roboflow-damage-01 --file ~/Downloads/img_001.jpg \
    --origin REAL_ROBOFLOW --source "https://universe.roboflow.com/<workspace>/<project>" \
    --license "CC BY 4.0" --catalog-id samsung-galaxy-a36-5g \
    --expected '{"image_relevance":"RELEVANT","visible_cracks":"VISIBLE"}'

Leave --expected out if you have not labelled it yet: the image is stored as READY_UNLABELED
(usable for demos, skipped by the accuracy eval).
"""
import argparse
import hashlib
import json
import sys
from datetime import date
from pathlib import Path

from PIL import Image, ImageOps

ROOT = Path(__file__).resolve().parent.parent
ORIGINS = ["REAL_OWN_PHOTO", "REAL_ROBOFLOW", "REAL_PUBLIC_DOMAIN", "REAL_OTHER"]


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--slot", required=True, help="slot id from manifest.json (status TO_COLLECT)")
    ap.add_argument("--file", required=True)
    ap.add_argument("--origin", required=True, choices=ORIGINS)
    ap.add_argument("--source", help="URL or who took it (required unless REAL_OWN_PHOTO)")
    ap.add_argument("--license", dest="lic", help="license text (required unless REAL_OWN_PHOTO)")
    ap.add_argument("--catalog-id", help="for pool slots: which catalog device this image is used for")
    ap.add_argument("--expected", help="JSON of ground-truth fields (names as in backend/src/ai/schemas.js)")
    ap.add_argument("--redacted", action="store_true", help="REQUIRED for invoices: confirms personal data was blacked out")
    a = ap.parse_args()

    mpath = ROOT / "manifest.json"
    manifest = json.loads(mpath.read_text(encoding="utf-8"))
    slot = next((i for i in manifest["images"] if i["id"] == a.slot), None)
    if not slot:
        sys.exit(f"Unknown slot {a.slot}. Slots: " + ", ".join(i["id"] for i in manifest["images"] if i["status"] == "TO_COLLECT")[:600])
    if a.origin != "REAL_OWN_PHOTO" and not (a.source and a.lic):
        sys.exit("Non-own images need --source and --license (check the dataset's license page first).")
    if slot["kind"] == "invoice" and not a.redacted:
        sys.exit("Real invoices must have names, phone numbers, addresses and card digits redacted. Re-run with --redacted once done.")
    expected = json.loads(a.expected) if a.expected else None

    img = ImageOps.exif_transpose(Image.open(a.file)).convert("RGB")  # exif_transpose then re-encode drops EXIF/GPS
    img.thumbnail((1568, 1568))
    out = ROOT / "real" / f"{a.slot}.jpg"
    out.parent.mkdir(parents=True, exist_ok=True)
    img.save(out, "JPEG", quality=88)
    if out.stat().st_size > 5 * 1024 * 1024:
        out.unlink()
        sys.exit("Image is over 5 MB after compression; the backend limit is 5 MB.")
    sha = hashlib.sha256(out.read_bytes()).hexdigest()
    dup = next((i for i in manifest["images"] if i.get("sha256") == sha), None)
    if dup:
        out.unlink()
        sys.exit(f"Duplicate of {dup['id']} (same pixels). Not added.")

    slot.update(
        file=f"real/{a.slot}.jpg", origin=a.origin, sha256=sha, bytes=out.stat().st_size,
        status="READY" if expected else "READY_UNLABELED", expected=expected,
        source=a.source or "team member's own photo", license=a.lic or "own work (team)",
        ingested_on=date.today().isoformat(),
    )
    if a.catalog_id:
        slot["catalog_id"] = slot["claim_ref"] = a.catalog_id
    mpath.write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8")

    with (ROOT / "SOURCES.md").open("a", encoding="utf-8") as f:
        f.write(f"| {a.slot} | {a.origin} | {slot['source']} | {slot['license']} | {date.today().isoformat()} |\n")
    print(f"OK  {a.slot} -> real/{a.slot}.jpg  status={slot['status']}")


if __name__ == "__main__":
    main()
