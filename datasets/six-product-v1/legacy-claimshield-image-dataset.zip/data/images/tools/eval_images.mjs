#!/usr/bin/env node
/**
 * Runs the image dataset through YOUR ClaimShield backend (real upload + real Claude Vision analysis)
 * and scores the extracted observations against manifest.json ground truth.
 *
 *   node data/images/tools/eval_images.mjs                       # all labelled READY images
 *   node data/images/tools/eval_images.mjs --only invoice-blurry  # filter by id/scenario substring
 *   node data/images/tools/eval_images.mjs --limit 10
 *   node data/images/tools/eval_images.mjs --mode cases --limit 6 # whole claims (multi-image) -> saves claim detail
 *
 * Before running: backend up (npm run dev), ANTHROPIC_API_KEY + CLAUDE_MODEL set, and
 * AI_DAILY_BUDGET_CALLS raised (default 20!) e.g. 200, then restart the backend.
 * Each image costs 1 Claude call. The script rotates throwaway accounts (10 AI calls/day/account limit).
 */
import { readFileSync, writeFileSync, existsSync } from "node:fs";
import { resolve, dirname, extname } from "node:path";
import { fileURLToPath } from "node:url";

const here = dirname(fileURLToPath(import.meta.url));
const root = resolve(here, "..");
const arg = (n, d) => {
  const i = process.argv.indexOf(`--${n}`);
  return i > -1 ? process.argv[i + 1] : d;
};
const BASE = arg("base", "http://127.0.0.1:3001");
const ONLY = arg("only", "");
const MODE = arg("mode", "images");
const LIMIT = Number(arg("limit", MODE === "cases" ? 12 : 1000));
const WAIT_MS = Number(arg("wait", 90)) * 1000;
const PER_ACCOUNT = 8;

const manifest = JSON.parse(readFileSync(resolve(root, "manifest.json"), "utf8"));
const casesFile = JSON.parse(readFileSync(resolve(root, "cases.json"), "utf8"));
const byId = new Map(manifest.images.map((e) => [e.id, e]));
const MIME = { ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png", ".webp": "image/webp" };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// ------------------------------------------------------------------ http
let session = { cookie: "", used: 0 };
let accountN = 0;
async function api(method, path, { json, form } = {}) {
  const headers = { "X-ClaimShield": "1" };
  if (session.cookie) headers.Cookie = session.cookie;
  let body;
  if (json) {
    headers["Content-Type"] = "application/json";
    body = JSON.stringify(json);
  }
  if (form) body = form;
  const res = await fetch(BASE + path, { method, headers, body });
  const setCookie = res.headers.getSetCookie?.() ?? [];
  const c = setCookie.find((x) => x.startsWith("cs_session="));
  if (c) session.cookie = c.split(";")[0];
  const text = await res.text();
  let data;
  try { data = JSON.parse(text); } catch { data = text; }
  return { status: res.status, data };
}
async function freshAccount() {
  session = { cookie: "", used: 0 };
  accountN += 1;
  const r = await api("POST", "/api/auth/register", {
    json: { name: `Eval Bot ${accountN}`, email: `eval-${Date.now()}-${accountN}@example.com`, password: "Eval-Dataset-2026-xK9!" },
  });
  if (r.status !== 201) throw new Error(`register failed ${r.status} ${JSON.stringify(r.data)}`);
}
async function ensureAccount() {
  if (!session.cookie || session.used >= PER_ACCOUNT) await freshAccount();
}

// ------------------------------------------------------------------ flow
function claimPayload(entryOrCase) {
  const id = manifest.identities[entryOrCase.claim_ref];
  return { ...id, ...(entryOrCase.claim_override || {}) };
}
async function uploadAndAnalyze(claimId, entry) {
  const file = resolve(root, entry.file);
  if (!existsSync(file)) throw new Error(`missing file ${entry.file}`);
  const form = new FormData();
  form.append("kind", entry.kind);
  form.append("file", new Blob([readFileSync(file)], { type: MIME[extname(file).toLowerCase()] }), entry.file.split("/").pop());
  const up = await api("POST", `/api/claims/${claimId}/evidence`, { form });
  const evId = up.data?.id ?? up.data?.evidence?.id ?? up.data?.evidence_id;
  if (!evId) throw new Error(`upload failed ${up.status} ${JSON.stringify(up.data).slice(0, 300)}`);
  const an = await api("POST", `/api/claims/${claimId}/evidence/${evId}/analyze`, { json: {} });
  session.used += 1;
  const t0 = Date.now();
  const PENDING = ["ANALYSIS_PENDING", "ANALYSIS_QUEUED"];
  const getEv = async () => (await api("GET", `/api/claims/${claimId}/evidence/${evId}/analysis`)).data?.evidence;
  let ev = await getEv();
  let status = ev?.processing_status ?? an.data?.status;
  while (PENDING.includes(status)) {
    if (Date.now() - t0 > WAIT_MS) return { status: "TIMEOUT", observations: null };
    await sleep(2000);
    ev = await getEv();
    status = ev?.processing_status ?? status;
  }
  let obs = ev?.observations;
  if (typeof obs === "string") { try { obs = JSON.parse(obs); } catch { obs = null; } }
  return { status, observations: obs, evidenceId: evId, message: ev?.processing_message };
}

// ------------------------------------------------------------------ scoring
const isUnknown = (v) => v == null || String(v).trim() === "" || String(v).trim().toUpperCase() === "UNKNOWN";
const squash = (s) => String(s).toUpperCase().replace(/\s+/g, "");
function normDate(s) {
  const t = String(s).trim();
  let m = t.match(/^(\d{4})-(\d{2})-(\d{2})/);
  if (m) return `${m[1]}-${m[2]}-${m[3]}`;
  m = t.match(/^(\d{1,2})[-/.](\d{1,2})[-/.](\d{4})$/);
  if (m) return `${m[3]}-${m[2].padStart(2, "0")}-${m[1].padStart(2, "0")}`;
  return t;
}
const COMPARE = {
  seller_name: (p, e) => squash(p).includes(squash(e)) || squash(e).includes(squash(p)),
  invoice_number: (p, e) => squash(p) === squash(e),
  invoice_date: (p, e) => normDate(p) === normDate(e),
  product_model: (p, e) => squash(p).includes(squash(e)) || squash(e).includes(squash(p)),
  serial_number: (p, e) => squash(p) === squash(e),
  customer_name: (p, e) => squash(p).includes(squash(e)) || squash(e).includes(squash(p)),
  gstin: (p, e) => squash(p) === squash(e),
  serial_text: (p, e) => squash(p) === squash(e),
  observed_brand: (p, e) => squash(p).includes(squash(e)),
  identifying_evidence_kind: (p, e) => squash(p) === squash(e),
  image_relevance: (p, e) => squash(p) === squash(e),
};
function scoreEntry(entry, obs) {
  const exp = entry.expected;
  const accept = new Set(exp.accept_unknown || []);
  const out = {};
  for (const [field, cmp] of Object.entries(COMPARE)) {
    if (!(field in exp)) continue;
    const e = exp[field];
    const p = obs?.[field];
    if (isUnknown(e)) out[field] = isUnknown(p) ? "correct" : "invented";
    else if (isUnknown(p)) out[field] = accept.has(field) ? "correct" : "missed";
    else out[field] = cmp(String(p), String(e)) ? "correct" : accept.has(field) ? "invented" : "wrong";
  }
  if (exp.image_quality_in) out.image_quality = exp.image_quality_in.includes(obs?.image_quality) ? "correct" : "wrong";
  return out;
}

// ------------------------------------------------------------------ main
async function runImages() {
  const items = manifest.images
    .filter((e) => e.status === "READY" && e.expected && (e.id + e.scenario).includes(ONLY))
    .slice(0, LIMIT);
  console.log(`Evaluating ${items.length} images against ${BASE}\n`);
  const results = [];
  for (const [i, entry] of items.entries()) {
    await ensureAccount();
    const c = await api("POST", "/api/claims", { json: claimPayload(entry) });
    if (c.status !== 201) { console.log("claim create failed", c.status, JSON.stringify(c.data).slice(0, 300)); break; }
    let r;
    try { r = await uploadAndAnalyze(c.data.id, entry); } catch (e) { r = { status: "ERROR", message: e.message }; }
    if (["AI_NOT_CONFIGURED", "LIMITED_MODE", "ANALYSIS_UNAVAILABLE"].includes(r.status)) {
      console.log(`\nStopped: ${r.status} - ${r.message ?? ""}\nSet ANTHROPIC_API_KEY/CLAUDE_MODEL and raise AI_DAILY_BUDGET_CALLS in .env, then restart the backend.`);
      break;
    }
    const scores = r.observations ? scoreEntry(entry, r.observations) : {};
    const ok = r.status === "ANALYSIS_COMPLETE" && Object.values(scores).every((s) => s === "correct");
    console.log(`${String(i + 1).padStart(3)}/${items.length} ${ok ? "PASS" : "FAIL"} ${entry.id} [${r.status}] ${Object.entries(scores).filter(([, s]) => s !== "correct").map(([f, s]) => `${f}:${s}`).join(" ")}`);
    results.push({ id: entry.id, scenario: entry.scenario, status: r.status, scores, pass: ok, observations: r.observations });
  }
  summarize(results);
  writeFileSync(resolve(root, "eval-results.json"), JSON.stringify({ ran_at: new Date().toISOString(), base: BASE, results }, null, 2));
  console.log("\nSaved data/images/eval-results.json");
}

function summarize(results) {
  const field = {}, scen = {};
  let invented = 0, scored = 0;
  for (const r of results) {
    (scen[r.scenario] ??= { pass: 0, n: 0 }).n += 1;
    if (r.pass) scen[r.scenario].pass += 1;
    for (const [f, s] of Object.entries(r.scores)) {
      (field[f] ??= { correct: 0, n: 0 }).n += 1;
      if (s === "correct") field[f].correct += 1;
      if (s === "invented") invented += 1;
      scored += 1;
    }
  }
  console.log("\nPer-field accuracy");
  for (const [f, v] of Object.entries(field)) console.log(`  ${f.padEnd(28)} ${v.correct}/${v.n}  ${((100 * v.correct) / v.n).toFixed(0)}%`);
  console.log("\nPer-scenario pass rate");
  for (const [s, v] of Object.entries(scen)) console.log(`  ${s.padEnd(28)} ${v.pass}/${v.n}`);
  console.log(`\nInvented values on must-not-invent fields: ${invented} of ${scored} scored fields`);
}

async function runCases() {
  const cases = casesFile.cases.filter((c) => (c.case_id + c.scenario).includes(ONLY)).slice(0, LIMIT);
  console.log(`Running ${cases.length} cases (multi-image claims) against ${BASE}\n`);
  const out = [];
  for (const cs of cases) {
    await ensureAccount();
    if (session.used + cs.images.length > PER_ACCOUNT) await freshAccount();
    const c = await api("POST", "/api/claims", { json: claimPayload(cs) });
    if (c.status !== 201) { console.log("claim create failed", cs.case_id, c.status); continue; }
    const statuses = [];
    for (const imgId of cs.images) statuses.push((await uploadAndAnalyze(c.data.id, byId.get(imgId)).catch((e) => ({ status: "ERROR", message: e.message }))).status);
    const detail = await api("GET", `/api/claims/${c.data.id}`);
    const inv = detail.data?.investigation ?? detail.data?.latest_investigation ?? detail.data?.investigations?.[0];
    console.log(`${cs.case_id.padEnd(64)} images:[${statuses.join(",")}] recommendation: ${inv?.recommendation ?? inv?.outcome ?? "(see json)"}`);
    out.push({ case: cs, claim_id: c.data.id, evidence_statuses: statuses, claim_detail: detail.data });
  }
  writeFileSync(resolve(root, "cases-results.json"), JSON.stringify({ ran_at: new Date().toISOString(), out }, null, 2));
  console.log("\nSaved data/images/cases-results.json (inspect the rules output against expected_relationships in cases.json)");
}

(MODE === "cases" ? runCases() : runImages()).catch((e) => { console.error(e); process.exit(1); });
