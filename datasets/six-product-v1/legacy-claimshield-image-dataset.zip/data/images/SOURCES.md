# Sources and licenses

Every non-generated image must appear here (ingest_real.py appends rows automatically).
Generated images (GENERATED_SYNTHETIC) are produced by tools/generate_dataset.py and need no attribution.

| id | origin | source | license | date |
|---|---|---|---|---|
