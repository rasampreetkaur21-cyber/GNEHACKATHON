# Collecting the REAL images (team checklist)

The generated set covers fraud logic and OCR edge cases with exact ground truth. The real set makes the
demo credible. Aim for about 30 real images. Slots are already listed in `manifest.json` (status TO_COLLECT).

## A. Your own photos (best, safest) - about 18 images
For each of the 6 catalog devices you can get hold of (borrow from friends/family; do NOT damage anything on purpose):
1. `real-<device>-back-label`: back of the device / headphone label showing the real serial or model text. Sharp, no flash glare.
2. `real-<device>-front`: overall photo.
3. `real-<device>-damage-closeup`: only if a genuinely damaged unit exists.
Tips: natural light, 20-30 cm away, one photo per slot, keep under 5 MB (the ingest tool resizes anyway).
Privacy: IMEI/serial of a friend's phone is personal-ish. Get consent, or blur the last digits and record
the blurred value as the expected serial.

## B. Roboflow Universe damage images - about 10 images
1. universe.roboflow.com, search: "cracked phone screen", "phone screen damage", "broken headphones".
2. Open a dataset, read its **License** badge. Use only CC BY / CC0 / public-domain style licenses. Skip "Private"/"Unknown".
3. Download a few images (any export format; you only need the pictures, not the labels).
4. Ingest each with the dataset URL and license:
   `python data/images/tools/ingest_real.py --slot real-roboflow-damage-01 --file <img> --origin REAL_ROBOFLOW --source <dataset URL> --license "CC BY 4.0" --catalog-id <device> --expected '{"image_relevance":"RELEVANT","visible_cracks":"VISIBLE"}'`
5. Credit the dataset in your demo slide / README.

## C. Real invoices - up to 4
Only your own genuine receipts. **Black out** name, phone, address, email, card digits and any GSTIN you
do not want public before ingesting (`--redacted`). If you cannot redact, skip: the generated invoices cover it.

## D. Retail websites (Amazon, Flipkart, brand pages)
Do not bulk-scrape. It breaches their terms and the images are copyrighted. If you want a couple of official product
images for a slide, use the manufacturer's own press/support page and credit it. They are not needed for the eval.

## Labelling what you ingest (`--expected`)
Use the same field names the backend extracts (backend/src/ai/schemas.js), for example:
`{"serial_text":"R58T1234567","observed_brand":"Samsung","identifying_evidence_kind":"LABEL","image_relevance":"RELEVANT"}`
Use "UNKNOWN" for anything not readable. Images without `--expected` are kept as READY_UNLABELED (usable in the demo,
skipped by the accuracy eval).
